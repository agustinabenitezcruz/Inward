---
version: 1
name: INWARD
description: Sistema de diseño de INWARD, consultora de inmigración y movilidad internacional en Francia. Fondo blanco, un único acento violeta oscuro #202045 tomado de la paleta primaria del brand book, y dos tintes ácidos (verde agua y amarillo) que aparecen sólo como fondo de celdas del bento. La geometría es rectángulo con esquinas redondeadas en una sola escala. La tipografía combina un display geométrico de x-height alta con un cuerpo tipo Futura. El ritmo lo da la alternancia entre blanco y el gris #eeeeee del brand book, nunca un fondo saturado: el violeta es acento, jamás fondo de sección. Serio pero luminoso, nunca corporativo azul-genérico.

brand:
  isotipo: hexágono (alusión al perímetro de Francia) con una flecha entrando
  fuente-de-verdad: assets/css/styles.css, bloque :root
  regla: ningún componente escribe un color a mano, todo sale de un token

colors:
  ground: "#ffffff"
  surface: "#eeeeee"
  surface-2: "#e3e3e6"
  text: "#101010"
  text-2: "#4d4d6b"
  text-3: "#71718f"
  accent: "#202045"
  on-accent: "#ffffff"
  accent-soft: "rgba(32,32,69,.09)"
  fill: "#202045"
  fill-hi: "#15152e"
  fill-ink: "#ffffff"
  line: "rgba(32,32,69,.15)"
  line-strong: "rgba(32,32,69,.3)"
  tint-1: "#55ffd2"
  tint-2: "#ebff76"
  tint-ink: "#101010"
  alt: "#eeeeee"
  alt-ink: "#101010"
  alt-ink-2: "#4d4d6b"
  alt-accent: "#202045"
  alt-label: "#71718f"

typography:
  display-xl:
    fontFamily: "Outfit, Figerona, 'Helvetica Neue', Arial, sans-serif"
    fontSize: "clamp(2.15rem, 3.9vw, 3.55rem)"
    fontWeight: 500
    lineHeight: 1.04
    letterSpacing: "-0.032em"
  display-lg:
    fontFamily: "Outfit, Figerona, 'Helvetica Neue', Arial, sans-serif"
    fontSize: "clamp(1.95rem, 3.4vw, 3rem)"
    fontWeight: 500
    lineHeight: 1.06
    letterSpacing: "-0.026em"
  heading-sm:
    fontFamily: "Outfit, Figerona, 'Helvetica Neue', Arial, sans-serif"
    fontSize: "clamp(1.1rem, 1.45vw, 1.3rem)"
    fontWeight: 500
    lineHeight: 1.26
    letterSpacing: "-0.012em"
  lead:
    fontFamily: "Jost, Walkway, 'Helvetica Neue', Arial, sans-serif"
    fontSize: "clamp(1.05rem, 1.4vw, 1.28rem)"
    fontWeight: 300
    lineHeight: 1.55
  body:
    fontFamily: "Jost, Walkway, 'Helvetica Neue', Arial, sans-serif"
    fontSize: 17px
    fontWeight: 400
    lineHeight: 1.62
  body-sm:
    fontFamily: "Jost, Walkway, 'Helvetica Neue', Arial, sans-serif"
    fontSize: "0.96rem"
    lineHeight: 1.6
  label:
    fontFamily: "Jost, Walkway, 'Helvetica Neue', Arial, sans-serif"
    fontSize: "0.7rem"
    fontWeight: 500
    textTransform: uppercase
    letterSpacing: "0.19em"
    color: accent

layout:
  container: 1360px
  gutter: "clamp(20px, 4.5vw, 64px)"
  navHeight: 72px
  sectionPadding: "clamp(4.5rem, 10vh, 7.5rem)"
  gridGap: 14px
  breakpoints: [600, 900, 1080, 1240]

shapes:
  radius: 18px
  radiusSmall: 10px
  radiusBand: 28px
  button: pill

motion:
  easeOut: "cubic-bezier(.23, 1, .32, 1)"
  easeInOut: "cubic-bezier(.77, 0, .175, 1)"
  press: "scale(0.97) en 160ms"
  reveal: "opacity + translateY(22px) en 700ms"
---

## Overview

INWARD es una consultora francesa de inmigración y movilidad internacional que
atiende a dos públicos a la vez: particulares que se instalan en Francia y
empresas que mueven colaboradores. El sitio tiene que transmitir rigor
administrativo sin caer en el azul corporativo genérico de la categoría.

La solución es un fondo blanco con **un solo acento**, el azul eléctrico
`#202045` de la paleta secundaria del brand book, y dos tintes ácidos que
aparecen únicamente como fondo de celdas dentro de una grilla. El ritmo de la
página no lo dan las tarjetas sino **dos bandas de color pleno** que cortan el
blanco en puntos fijos.

Serio pero luminoso. La fotografía es real, de luz natural y clave alta, y por
eso el fondo es blanco: sobre oscuro las fotos se leen como recortes pegados.

El hero ocupa el alto completo de la ventana (`100svh`, nunca `vh`) con video de
fondo a sangre.

## Colors

### Ritmo de fondos

Sólo dos fondos de sección: **blanco `#ffffff` y gris `#eeeeee`**, el gris del
brand book. Alternan: blanco (B2B), gris (logos de clientes), blanco (B2C),
gris (quiénes somos), blanco (recursos), gris (contacto), blanco (footer). El
hero es la excepción: video a sangre con texto blanco.

**El gris nunca arranca ni termina con una línea.** Entra y sale con degradado,
así que en toda la página no queda ni un borde horizontal visible. Medido: cero
saltos bruscos de luminancia por debajo del hero. Un borde duro cada 800 px es
lo que hace que una página se lea como bloques apilados, que es justo lo que la
clienta no quería.

**El bloque gris de empresas no es sólo `#entreprises`.** Arranca tiñendo la
mitad inferior de la sección de avis, cubre empresas y sigue por la franja de
logos, que es su prueba social y ya vive pegada a su CTA. Vuelve al blanco
dentro del padding superior de particulares.

Las celdas del bento pasan a **blancas**: sobre una sección gris, una celda gris
sólo existiría por su borde.

Eso obliga a una excepción a la regla de abajo. El bloque que se va es la franja
de logos, de 86 px, y una rampa de 0,17 de luminancia en 86 px banda. **Cuando
el bloque que se va es un intersticio, la rampa se muda al padding del que
llega**, porque una rampa necesita largo antes que dueño.

**El degradado de entrada vive en la sección de arriba, no en la gris.** La
banda de contacto es gris plano de punta a punta; quien se tiñe es la sección de
recursos, en toda su mitad inferior. Un degradado largo que ocupa media sección
disimula el límite mucho mejor que uno corto encerrado dentro de la sección
gris, donde el ojo todavía encuentra dónde empieza el color. La regla general:
la transición pertenece al bloque que se está yendo.

**Excepción, y es la única: el footer corta en seco.** Ese sí es un borde que
queremos que se lea: es el final de la página, no una costura entre dos
secciones.

**La salida del gris vive en la sección gris**, por la misma regla: la
transición pertenece al bloque que se está yendo. Mientras el footer venía justo
después de contacto no hacía falta, porque ese corte lo queríamos. Al meter la
FAQ en el medio, el gris pasó a terminar contra el blanco y apareció un filo de
**0,145** de luminancia, el único de la página por debajo del hero. Medido, no
estimado: cuando se agrega una sección hay que volver a pasar el escáner de
costuras, porque una sección nueva cambia quién limita con quién.

**Ninguna sección lleva fondo saturado.** El violeta es acento, nunca fondo. Una
banda azul a sangre compite con la fotografía y con los tintes del bento, y
convierte la página en un damero. Si una sección necesita separarse de la
anterior, la respuesta es el gris, no el color.

### Acento

Hay **un** acento en toda la página: `#202045`, el VIOLETA OSCURO de la paleta
primaria. Es la combinación que eligió la clienta: paleta secundaria (verde
agua y amarillo como tintes) con el violeta oscuro de la primaria como acento.
Se descartó el azul `#3600f9`, que daba 8,5:1 sobre blanco contra los 15:1 del
violeta y leía más eléctrico que profesional. Es a la vez color de texto de
acento (labels, links, títulos destacados) y relleno de los CTA, con texto
blanco encima. Da 9,5:1 sobre blanco, así que sirve para ambas cosas sin
inventar una segunda variante.

No existe un segundo acento. Si una sección parece necesitar otro color, la
respuesta es tinte de fondo, no acento nuevo.

### Tintes

`--tint-1` verde agua `#55ffd2` y `--tint-2` amarillo `#ebff76` son **fondos de
celda**, nunca color de texto ni de icono suelto. Ambos llevan texto `#101010`
encima. Su función es romper una grilla que si no sería de tarjetas planas
todas iguales.

**Máximo dos celdas tintadas por grilla, y nunca contiguas.** Se usan en el
bento de empresas (2 de 5) y en las tarjetas del blog (2 de 3, con la del medio
neutra). Una tercera tinta o dos pegadas convierten la sección en un mosaico y
le sacan jerarquía al acento.

Sobre tinte, el texto secundario baja a `opacity: .75` y el metadato a `.68`.
Por debajo de eso el texto chico deja de pasar AA sobre el verde agua.

### Bandas alternas

Los tokens `--alt-*` visten las secciones grises. Son gris con texto oscuro.
Existen como grupo aparte para poder afinarlas sin tocar el resto, no porque
tengan otro esquema de color.

### Neutros

Los grises están sesgados hacia el violeta (`#4d4d6b`, `#71718f`) y las líneas
son el azul de acento a baja opacidad, no gris neutro. Es lo que hace que el
blanco no se sienta frío.

### Regla dura

Ningún componente escribe un hex a mano. Todo sale del bloque `:root` de
`assets/css/styles.css`. Cambiar de paleta es cambiar ese bloque.

## Typography

### Familias

- **Display:** Outfit. Geométrica, x-height alta, aperturas cerradas. Sustituye
  a **Figerona**, la tipografía de titulares del brand book.
- **Cuerpo:** Jost. Geométrica tipo Futura, x-height baja, formas redondas
  amplias. Sustituye a **Walkway**, la de textos del brand book.

El contraste entre las dos no es de estilo sino de x-height y de ancho. Por eso
funcionan juntas siendo ambas geométricas.

### Jerarquía

El peso hace el trabajo, no el tamaño. Display siempre en 500, nunca 700: la
escala y el tracking negativo (`-0.032em` en h1) ya dan presencia. El `lead` va
en 300 para abrir aire bajo cada titular.

Los labels de sección son versalitas de 0.7rem con `letter-spacing: 0.19em` en
color de acento. **Máximo uno cada tres secciones.** Un label sobre cada
titular produce el ritmo templado de sitio generado.

El titular del hero es la excepción a la escala: tiene la suya,
`clamp(2.15rem, 5.7vw, 5.1rem)`, bastante por encima del h1 general. Es la única
pieza que compite con un video a pantalla completa, y con el tamaño heredado y
tres líneas cortas ocupaba poco más de un tercio del ancho: el video se lo
comía. Dos líneas largas lo estiran de punta a punta del contenedor.

**Los cortes de línea del hero están escritos en el marcado**, en `<span
class="ln">`, porque cada uno entra con su propio retardo. Eso obliga a dos
cosas. No lleva `max-width`: un tope en `ch` sólo podría provocar un tercer
salto que nadie previó. Y por debajo de 900 px los tramos pasan a `inline` para
que el texto fluya solo, porque esos cortes en un teléfono darían cinco líneas
visuales con quiebres en lugares raros; ahí la entrada se anima en bloque, ya
que una animación de `transform` no tiene efecto sobre una caja inline.

### Nota sobre las sustituciones

Figerona y Walkway no están auto-hospedadas todavía. Figerona es licencia de
uso personal: para producción hay que comprar licencia comercial o cambiarla.
Cuando lleguen los .woff2 se declaran con `@font-face` y sólo cambian
`--font-display` y `--font-body`.

## Layout

### Cabeceras de sección

El ancho lo fija cada elemento, **nunca el contenedor**. Un `max-width` en `ch`
sobre el contenedor se mide con la tipografía del cuerpo y estrangula un titular
de 48 px a media columna. La regla:

- titular: `max-width: 18em`, en `em`, así escala con su propio tamaño
- párrafo de entrada: `max-width: 56ch`, que es medida de lectura

Cuando la cabecera deja mucho blanco al costado, la solución es `.sec-head-row`:
titular a la izquierda y **un elemento funcional** a la derecha, alineados por
la base. Nunca un párrafo de relleno flotando en la columna derecha.

Contenedor de 1360 px con gutter fluido de 20 a 64 px. Grilla de 14 px de gap
en todo el sitio, sin excepción.

El bento del bloque de empresas es asimétrico de seis columnas: una celda de
`span 4` con foto y cuatro de `span 2`. **Tantas celdas como contenido haya**;
si sobra un hueco, la grilla está mal planteada, no falta una tarjeta vacía.

Ninguna familia de layout se repite. A lo largo de la página: hero a sangre con
cifras, bento asimétrico, fila de logos, lista de filas que se abren con vista
previa, split de retratos, grilla de tres tarjetas, split de formulario. Siete
estructuras distintas.

Las cabeceras de sección van apiladas (label, titular, párrafo) y el CTA de la
sección va **después** del contenido, nunca en la cabecera.

Todo layout multicolumna declara su colapso a una columna antes de 900 px.

## Shapes

Una sola escala de radios, sin excepciones:

| Token | Valor | Dónde |
|---|---|---|
| `--r` | 18 px | Media, celdas del bento, tarjetas. Utilidad `.rounded` |
| `--r-band` | 28 px | Esquinas superiores de la banda que se desliza sobre el hero |
| `--r-sm` | 10 px | Campos de formulario |
| — | pill | Botones y selector de idioma |

No hay ningún `border-radius` suelto en el CSS. Un componente nuevo usa
`.rounded` o una de esas variables.

## Components

### Métricas

Van **dentro del hero**, en una tira horizontal debajo de los CTA, separadas por
un hairline. Números chicos (2,15 rem como máximo) con su etiqueta debajo.

Las tres cifras son **reales y confirmadas por la clienta**: 99 % de tasa de
éxito, +45 nacionalidades acompañadas, +1000 expedientes tratados. Ninguna
está inventada ni redondeada por nosotros.

Se probaron antes como sección propia sobre banda de color, primero con tres
columnas iguales y después con una cifra en display gigante. Las dos versiones
fallaron por lo mismo: una cifra sola no llena una sección entera. En el hero
refuerzan el mensaje sin pedir su propio bloque, y la página arranca directo en
los servicios.

Es el patrón de Revolut, una de las referencias del brief.

### Botones

Pill. El primario es relleno de acento con texto blanco; el fantasma es
transparente con borde `--line-strong`. `scale(0.97)` en `:active` a 160 ms:
sin ese feedback el botón se siente muerto.

**El relleno de los CTA es el violeta `#202045`.** Se probó pasarlos a los
tintes de la paleta y se volvió atrás. La medición explica por qué conviene
dejarlo así:

| Relleno | Texto sobre el botón | Botón sobre gris | Botón sobre blanco |
|---|---|---|---|
| Violeta `#202045` | 15,5:1 | **13,4:1** | **15,5:1** |
| Verde agua `#55ffd2` | 15,1:1 | 1,09:1 | 1,26:1 |
| Amarillo `#ebff76` | 17,3:1 | 1,06:1 | 1,10:1 |

El texto se lee perfecto en los tres. Lo que cambia es **cuánto se despega el
botón del fondo**. Con un tinte, el CTA existe por su texto, no por su forma.
Y hay un segundo motivo: verde agua y amarillo ya son colores decorativos acá
(bento, blog, FAQ, mega menú), así que un CTA tintado deja de ser lo único con
derecho a ese color y se confunde con el relleno de al lado.

**Los dos botones del hero son la excepción: blancos con el texto en violeta.**
El pie del velo del hero deja el fondo en 0,015 de luminancia y el violeta sobre
eso da **1,05:1**: el botón existía como texto pero no como forma. En blanco da
16:1. El acento no desaparece, se muda al texto.

Y son iguales entre sí. Uno relleno y otro fantasma hacía que el segundo
pareciera una opción de segunda, cuando las dos audiencias valen lo mismo y el
orden ya dice cuál va primero. Van también un punto más grandes que el resto de
los botones, porque compiten contra una imagen a pantalla completa y no contra
fondo blanco.

### Orden de las audiencias

**Empresas va siempre primero.** En el menú, en los botones del hero, en el
selector del formulario, en las columnas del pie y en el orden de las secciones.
No es alfabético ni casual: es la audiencia de mayor valor por dossier y la
clienta quiere que sea lo primero que se ve. Cualquier par
particulier/entreprise que se agregue después sigue esta regla.

### Celdas y tarjetas

**Las cinco celdas de empresas son iguales: mismo ancho, mismo alto, misma
tipografía.** Antes una de ellas llevaba foto, ocupaba cuatro columnas de seis y
el doble de alto, así que a simple vista parecía el servicio principal y los
otros cuatro, secundarios. Son cinco prestaciones del mismo rango. Al bajar de
ancho cambia la cantidad de columnas (5 → 3 → 2 → 1), nunca el tamaño relativo
de una celda: en la última fila queda un hueco vacío, y está bien, es una
grilla incompleta y no una jerarquía.

Los dos tintes se mantienen, alternados en la segunda y la cuarta. Alternar lee
como ritmo, no como ranking; lo que leía como ranking era el tamaño.

**Todas las secciones entran enteras en pantalla.** No sólo empresas y
particulares: es una regla de la página. Verificado a 1280×800, 1366×768,
1440×900, 1512×982, 1728×1117 y 1920×1080, descontando los 72 px de la barra
fija. El piso está en unos 730 px de alto útil; por debajo de eso el contenido
no comprime más sin quedar apretado, y parte de la culpa es que `--band-gap`
es fijo y no encoge con la ventana.

**Corolario para cualquier bloque nuevo: el alto se mide contra la ventana, no
contra el ancho.** La banda a sangre de "Qui sommes-nous" empezó con
`aspect-ratio: 16/5` y crecía con el ancho de la pantalla, 450 px a 1440 y 472
a 1512, justo lo que hacía que la sección no entrara. Con
`height: clamp(160px, 24svh, 280px)` entra siempre. Es lo que pagó quitar la foto del bento, apretar los encabezados
y dejar el acordeón de particulares cerrado al cargar: una fila abierta por
defecto costaba 94 px y en un portátil de 768 px de alto era la diferencia entre
ver la sección completa o no.

**Todas las cajas de la página llevan el mismo borde**, del token
`--line-card` (`rgba(32,32,69,.24)`): celdas del bento, tarjetas del blog,
tarjetas de avis, preguntas de la FAQ, el bloque de llamada del mega menú y el
panel del formulario. También las tintadas, que antes lo llevaban transparente.

Es una sola línea para todas a propósito: si alguien la quiere más marcada o
más suave, toca el token y cambian las seis familias a la vez. Un borde por
componente es cómo se llega a lo que había antes, que era tres criterios
distintos conviviendo.

Más oscura que `--line` porque su trabajo es distinto: `--line` separa cosas
dentro de un bloque (filetes, campos), `--line-card` recorta la caja del fondo
para que no flote.

Las celdas del bento se agrupan por **relleno** además del borde. El contenido va
**arriba**, no abajo: una caja con el texto pegado al piso y aire muerto encima
se lee como un error de maquetado, no como respiro. La celda con foto es la
excepción, porque su texto va sobre el degradado inferior de la imagen. Las tarjetas del
blog al revés: fondo blanco con borde de 1 px. Dos tratamientos distintos
porque son dos jerarquías distintas; no se mezclan.

**El hover es uno solo para toda la página**: la tarjeta sube 4 px y proyecta
sombra. Da igual que sea celda del bento o tarjeta del blog, tintada o no. Antes
había tres comportamientos conviviendo (celda que sólo subía, tarjeta gris que
subía y cambiaba el borde a acento, tarjeta tintada que sólo subía porque el
borde no se ve sobre relleno de color) y al recorrer la página se notaba como
inconsistencia. El borde no sirve como señal común justamente porque las
tintadas no lo tienen; la sombra sí funciona en los dos casos.

El levante se escribe en `translate`, **no** en `transform`. Las tarjetas llevan
`.rv`, cuya animación `riseIn` corre con `both` y por lo tanto queda dueña de
`transform` de forma permanente: una animación gana sobre cualquier declaración
normal en la cascada, así que un `transform` en `:hover` no se renderiza nunca.
`translate` es una propiedad independiente y se compone con el `transform` de la
animación. Lo mismo vale para la transición: `transition:translate`, no
`transition:transform`.

Nada lleva sombra en reposo salvo elementos que flotan de verdad: el mega menú y
el panel de notas. Las sombras van tintadas con el acento, nunca negro puro.

### Qui sommes-nous

**No lleva retratos de las fundadoras.** La sección cuenta qué es INWARD, no
quién la firma; los nombres siguen en el JSON-LD, que es donde sirven. Las
fotos de retrato están en `assets/img/` por si vuelven en la página interna.

**Su maquetado es deliberadamente distinto al de particulares**, que viene
inmediatamente antes. Allá son dos columnas, una lista de filas separadas por
filetes horizontales y una foto al lado del texto. Acá no hay dos columnas: es
una pila editorial a todo el ancho, enunciado → imagen a sangre → tres pilares
separados por filetes **verticales** → acción. Eje contrario en los filetes, y
la foto no convive con el texto sino que corta la página de borde a borde. Es,
junto al hero, el único bloque a sangre.

Dos secciones seguidas con la misma familia de maquetado se leen como la misma
sección repetida dos veces, por más que el contenido cambie.

Apilados en pantalla chica los pilares vuelven al filete horizontal: una raya
vertical entre dos bloques que ya no están lado a lado no separa nada.

### FAQ

Otro acordeón, pero **no el mismo que el de particulares**. Allá son filas
separadas por filetes horizontales sobre el fondo de la sección; acá son
bloques con relleno gris separados por aire. Regla contra relleno: el mismo par
de opuestos que ya distingue las celdas del bento de las tarjetas del blog. El
marcador también cambia, un chevron que rota en vez de la cruz.

**Ciclo de tres: verde agua, amarillo, gris.** Sólo los dos tintes de la
paleta; el gris hace de tercer tiempo. Con dos colores alternados y nada más,
seis bloques dan un damero, y el gris rompe ese ritmo sin meter un color que no
es de la marca. Se probó con el lila `#d2d2ff` como tercer tinte y la clienta
lo descartó: **el lila no forma parte de esta paleta.**

Ninguna queda sin color por jerarquía: el gris es un tiempo del ciclo, no una
pregunta menos importante.

Usa **`<details>` nativo, no un botón con JavaScript**. Se abre sin JS, el
teclado y los lectores de pantalla ya saben qué es, y el buscador ve las
respuestas aunque estén cerradas. El despliegue se anima con
`::details-content` e `interpolate-size` donde el navegador lo soporta; donde
no, abre de golpe, que es el comportamiento nativo de siempre.

**El tinte vive en el `summary`, no en la tarjeta.** La pregunta conserva su
color al abrirse y lo que se pone gris es el panel de la respuesta, así la fila
de colores se sigue leyendo entera aunque haya una abierta. La abierta se
enmarca con un filete interior de `rgba(16,16,16,.18)`, que es la única señal
disponible: el fondo de la pregunta ya no puede cambiar.

Lo que **no** sirve como señal de estado es el acento: con el violeta oscuro,
un título en acento sobre un fondo claro es casi indistinguible del texto
normal, porque `#202045` contra `#101010` no se lee como un cambio. Vale para
toda la página: el acento quedó como color de acción, no de estado.

Todas cerradas al cargar. Seis respuestas abiertas hacen una sección más alta
que la pantalla, y la primera pregunta no es más importante que las otras cinco.

Cuando lleguen las respuestas reales conviene agregar el JSON-LD `FAQPage`.
Hoy no: Google exige que las respuestas marcadas sean las que el visitante ve,
y cinco de las seis todavía no existen.

### Footer

Cierra la página con **el mismo peso que el header**: negro de marca `#0f0f12`,
logo a 38 px, cuatro columnas de enlaces y el selector de idioma.

**Borde recto de lado a lado, sin esquinas redondeadas.** Se probó con el mismo
redondeo que usa la primera sección sobre el hero y ahí no funciona: el hero
sigue existiendo detrás, así que ese panel se apoya sobre algo. El footer no
tiene nada debajo. Redondeado leía como una tarjeta más en una página que ya
tiene muchas, y dejaba dos cuñas de gris en las puntas superiores sin nada que
las justifique. Es el final de la página y corta de punta a punta.

Redefine sus propios tokens en claro, igual que el header sobre el video: el
violeta `#202045` no se lee sobre negro, así que el acento del footer pasa a
verde agua `--tint-1`, que sí está en la paleta. Sólo pinta el hover de los
enlaces. Antes era el lila `#d2d2ff`, descartado con el resto del lila.

**El logo del pie va entero en blanco.** El isotipo toma `--accent`, y como el
pie redefine el acento para el hover de los enlaces, el isotipo se pintaba de
ese color. Un isotipo de un color distinto al de la cabecera no es una variante,
es otra marca.

Se probó bajando con degradado de blanco a negro y quedaba como una nube gris.
Un panel es una forma deliberada; una rampa larga parece un error de render.
Es la única excepción a la regla de no usar bordes duros, y lo es porque es una
forma, no una costura.

### Header

72 px de alto, una sola línea. Sobre el video del hero es **transparente y
redefine sus propios tokens en blanco**, así que el logo y los links se adaptan
solos sin blancos escritos a mano. Se vuelve blanco opaco al scrollear, y
también al abrir un mega menú, porque si no el panel quedaría con texto blanco
sobre fondo blanco.

El mega menú es a ancho completo, con las columnas alineadas al contenedor.
Cuidado con el shorthand `padding`: pisa el `padding-inline` heredado del
contenedor y el contenido termina pegado a los bordes.

### Menú desplegable (por debajo de 1080 px)

**El panel es el mismo `<nav>` de escritorio**, no un segundo menú. La consulta
media lo convierte en un panel a pantalla completa y reordena los mega menús
como acordeón. No hay marcado duplicado, así que no existe la posibilidad de que
una versión tenga un enlace que la otra no.

En escritorio los grupos se abren con `:hover` y no interviene JavaScript. En el
panel eso no existe: cada grupo se abre al tocarlo y se marca con `data-open` en
el `.nav-item`. **La consulta media es la única fuente de verdad sobre el ancho**;
el JS pregunta por ella con `matchMedia`, nunca compara `innerWidth` contra un
número escrito aparte, que es como se llega a dos criterios que discrepan.

El panel va **`position: absolute` contra la barra, no `fixed` contra la
ventana**. La barra lleva `backdrop-filter` cuando está sólida, y un elemento con
`backdrop-filter` se convierte en el bloque contenedor de sus descendientes
fijos: un `position: fixed` ahí queda recortado a los 72 px de alto de la barra y
del panel se ve apenas la primera línea. Peor todavía, el recorte aparece y
desaparece según la barra esté sólida o transparente.

**Dentro del panel el mega menú va a dos columnas**, no en una lista corrida.
Ocho entradas con subtítulo en una sola columna dan un scroll largo en el que
hay que recordar dónde empezaba cada grupo; en dos columnas los dos grupos se
ven a la vez y el menú entero entra en una pantalla de tablet. El bloque de
llamada ocupa el ancho completo debajo, que es donde se lee como cierre y no
como una tercera categoría. Por debajo de 640 px vuelve a una columna: dos
columnas de títulos largos en un teléfono no entran.

El contenido del grupo abierto va **sangrado a los dos lados** respecto del
título que lo abre. La sangría es lo que muestra la jerarquía, y de paso lo
despega del borde del panel, donde antes quedaba 3 px a la izquierda del propio
título. A los dos lados y no sólo a la izquierda porque el bloque de llamada
ocupa el ancho completo y con un solo lado se vería descentrado. El filete que
separa los grupos sigue de lado a lado: es lo que deja claro que el contenido
sangrado pertenece al grupo de arriba.

Al pasar `.mega-in` a grilla hay que anularle el `margin-inline: auto` que
hereda de `.wrap`. **Un item de grilla con márgenes automáticos deja de
estirarse y se centra sobre su ancho de contenido**: el panel se veía como una
columna angosta flotando en el medio de la pantalla.

El plegado usa `grid-template-rows: 0fr → 1fr` sobre un hijo con
`overflow: hidden`, igual que el acordeón de B2C. **El relleno de abajo va en el
último hijo, no en la caja recortada**: el padding propio de un elemento no lo
recorta su propio `overflow`, y el grupo cerrado deja ver una franja con el
primer título adentro.

Al abrir, el scroll del documento se bloquea. Sin eso el dedo arrastra la página
detrás del panel y al cerrar el visitante aparece en otra parte del sitio. Al
pasar a escritorio el panel se cierra por JS: si quedara marcado abierto, el
bloqueo del scroll sobreviviría al cambio de ancho.

### Favicon

**Isologo en violeta oscuro sobre fondo transparente**, sin el cuadrado de
color que tenía antes. Se genera a partir de `assets/img/logo/inward-isotipo.svg`
y sale en `favicon.svg`, `favicon.ico` (16 y 32) y los PNG de 192 y 512.

**El `apple-touch-icon` es la excepción y va sobre blanco.** iOS no respeta la
transparencia: compone el icono sobre negro, y un isologo violeta oscuro sobre
negro desaparece. Blanco con el isologo violeta es la misma identidad y se ve.

### Rail de secciones

Un filete vertical de 2 px con el segmento activo en acento y escalado. **No** se
repite el isotipo seis veces al costado: una marca que se repite deja de ser
marca. El logo aparece dos veces por página, header y footer, y nada más.

Va a **un tercio del margen izquierdo, no a la mitad**: es un indicador anclado
a la ventana, no una columna de contenido. A mitad de camino quedaba pegado al
texto y competía con la lectura. En pantallas anchas el margen crece pero el
riel se queda cerca del borde, que es donde tiene que estar; el `max(16px, …)`
evita que lo toque a 1241 px, el ancho más angosto en el que todavía se muestra.
Por debajo de 1240 px desaparece.

### Lista de servicios en acordeón

La cabecera de esta sección va **dentro de la columna de texto**, no encima de
las dos. Así la foto arranca a la misma altura que el label y termina a la
misma altura que el CTA: los dos bloques comparten borde superior e inferior.
Si la cabecera queda afuera, la foto empieza más abajo y la fila se desalinea.

La foto **se estira hasta el alto de esa columna** (`align-items: stretch`), no
impone su propia proporción. Con un 3/4 fijo
sobresalía por abajo y parecía caerse de la sección. El recorte va con
`object-position: 50% 34%` para que las caras no queden cortadas cuando el
alto baja.


Filas separadas por hairline. Un clic abre, otro cierra, y se puede quedar todo
cerrado. **Sin apertura al pasar el cursor:** volvería a abrir la fila que
acabás de cerrar. La fila abierta se marca sólo con el título en acento y el
signo rotado a cruz, sin fondo de color: un lavado violeta detrás del texto
ensucia y compite con las bandas plenas.

El aviso previo queda en la última imagen al cerrar, así el bloque no se vacía.

**Por debajo de 900 px la foto se oculta entera.** En una columna cae después
del acordeón, o sea al final de una lista larga y plegable, donde casi nadie
llega. Y su única función es cambiar al abrir cada fila: si no se ve al mismo
tiempo que la fila que la dispara, no comunica nada. Dejarla ahí de adorno
alarga la sección sin dar información. El `display: none` además evita que se
descarguen las cuatro imágenes, porque un `loading="lazy"` dentro de una caja
sin renderizar nunca llega a interseccionar el viewport.

### Avis Google

Familia de maquetado propia: bloque de nota fijo a la izquierda y un **carril
horizontal** de tarjetas a la derecha. El carril no es un capricho: la API
devuelve **entre una y cinco** opiniones y ese número cambia solo, sin que nadie
toque el código. Una grilla de tres se rompe sola en cuanto llegan cuatro. Un
carril acepta cualquier cantidad sin recomponer nada, y mantiene la sección en
una sola fila, que es lo que le permite entrar en pantalla.

El carril **no se desplaza solo**. Un marquee automático en un bloque de texto
obliga a leer a la velocidad de la animación.

Va **antes de Empresas**, apenas terminado el hero: es la prueba social que
sostiene todo lo que viene después. Los logos de clientes siguen donde estaban,
pegados al CTA de empresas. Son dos pruebas distintas para dos audiencias: las
opiniones vienen de particulares, los logos de empresas.

**Lo que muestra cada tarjeta no es decorativo, es obligatorio.** Nombre y foto
del autor, fecha relativa y enlace a la opinión original los exige la política
de Google; la fecha de la visita la exige la ley francesa. Ninguno de esos
elementos se puede quitar por razones de diseño.

Si no hay datos, la sección muestra el aviso de pendiente. **Nunca una opinión
inventada**: un testimonio falso en un sitio de un despacho es un problema
legal, no una licencia de maquetado.

### Fila de logos de clientes

Gris al reposo con opacidad 0,72, color al hover. Cada logo lleva su propia
altura calculada según su proporción: un mot-symbole ancho a 26 px, una marca
compacta a 41 px. Si se les da la misma altura a todos, la fila queda
descompensada. Sólo logos, nunca una etiqueta de rubro debajo.

Es una **franja intersticial**, no una sección: va sobre blanco liso y no lleva
padding propio. Todo su respiro sale del token `--band-gap`, hoy **65 px**, y la
relación es **1:2, menos arriba que abajo**: `#entreprises` cierra con
`--band-gap` y `#particuliers` abre con el doble.

El valor es fijo, no relativo al alto de la ventana como el resto del padding
vertical de la página. Es una distancia entre dos piezas concretas, no un ritmo
de página: la franja tiene que quedar a la misma distancia del CTA en un portátil
y en un monitor grande.

No es simetría, y es a propósito. La prueba social pertenece al CTA de empresas:
pegada a él funciona como su respaldo justo cuando alguien está por pedir una
reunión, y separada de la sección siguiente deja claro que no es el encabezado
de Particuliers. Se probó centrada, con el mismo aire de los dos lados, y la
franja se leía como una sección suelta sin dueño.

La escritura importa tanto como el valor: **la relación vive en un solo lugar**.
Si el respiro se reparte entre el padding de la banda y el de las dos vecinas,
mantener el 1:2 obliga a recalcular tres selectores cada vez que se toca uno.

### Formularios

Label arriba del campo, siempre. Nunca placeholder como label. Foco con borde
de acento más un halo de 3 px en `--accent-soft`.

**Un solo formulario con dos perfiles.** Empresa pide razón social y sólo
acepta correo profesional; particular no. El campo que no corresponde se quita
con el atributo `hidden` y `disabled`: así sale del formulario y del recorrido
por teclado, en vez de quedar invisible pero enfocable y enviándose igual.

**Para que `hidden` funcione hay que declararlo.** `[hidden] { display: none }`
vive en la hoja del navegador y tiene especificidad cero, así que cualquier
`display` escrito en una clase le gana. `.fld { display: grid }` lo pisaba y el
campo de razón social se seguía viendo en el perfil particular con el atributo
puesto. La hoja declara `[hidden] { display: none !important }` para todo el
sitio.

El correo profesional se valida **listando lo que no se acepta** (mensajerías
personales y desechables), no listando lo permitido: al revés dejaría afuera a
cualquier empresa con un dominio que no conozcamos, que son casi todas.

**El error tiene su renglón reservado debajo del campo.** Si aparece y empuja
el resto del formulario, el clic que el visitante ya tenía apuntado cae en otro
lado. Por el mismo motivo el mensaje es corto: en dos renglones desborda la
reserva y vuelve a empujar.

**Las celdas de una fila de dos campos van con `align-items: start`.** Por
defecto se estiran a la altura de la más alta, y el campo de email es más alto
porque reserva el renglón del error: el de nombre se estiraba para igualarlo y
su caja quedaba 11 px más alta y 10 px más abajo que la de al lado.

El rojo del error es un color propio, `#b3261e`, no un token de marca. Un error
tiene que leerse como error, y el violeta de INWARD es justamente el color de
lo que está bien: botones, enlaces, foco.

## Motion

**La continuidad es un requisito del brief, no un adorno.** La clienta pidió
explícitamente que la página no se sintiera cortada por sección. Tres cosas la
sostienen, y las tres tienen que sobrevivir a cualquier rediseño:

1. Los fondos entran y salen con degradado, sin bordes duros.
2. El reveal va atado al scroll con `animation-timeline: view()`: el elemento
   avanza con la rueda en vez de aparecer de golpe al cruzar un umbral. El
   `IntersectionObserver` queda sólo de reserva para navegadores sin soporte.
3. Parallax suave en las fotos grandes, que se mueven a otra velocidad que la
   página y desdibujan dónde empieza cada sección.

El padding vertical tampoco es igual en todas las secciones: un ritmo idéntico
una tras otra también las hace leer como bloques sueltos.

Cada animación tiene que poder justificarse en una frase. Las que hay:

- **Hero:** a `100svh`, con video de fondo. Las líneas del h1 suben con reveal
  por clip, escalonadas 90 ms.
- **La barra tiene su propio velo cuando flota sobre el vídeo.** Medido: en los
  tramos claros del vídeo el fondo detrás del menú llega a 0,754 de luminancia y
  el texto blanco daba **1,31:1**, ilegible. El velo del hero no alcanza, porque
  arriba es justamente donde más lo aclaramos para que se viera el edificio.
  Éste es local, 72 px de alto y se desvanece, así que no oscurece la imagen,
  sólo la franja de la barra. Con él: menú 6,9:1 y logo 8,3:1 en el peor punto.
  Va en un pseudo-elemento para poder desvanecerlo con la misma transición con
  la que la barra se vuelve sólida.
- **El velo del hero se concentra abajo, donde está el texto**, y suelta la
  parte alta de la imagen. Antes era una capa casi pareja que tapaba también el
  edificio y dejaba el hero mucho más oscuro que el resto de la página, que es
  clara. Las paradas del degradado están calculadas contra el contraste real
  del texto blanco sobre el vídeo, no a ojo: el tercio superior quedó un 72 %
  más luminoso y, aun así, el titular pasó de 2,87:1 (por debajo del mínimo) a
  3,22:1. Si se cambia el vídeo hay que volver a medir.
- **Continuidad:** el hero es sticky y las bandas siguientes se deslizan por
  encima con el radio superior abierto. Es lo que evita que la página se sienta
  como bloques separados.
- **Salida del hero:** `animation-timeline: scroll()`, fuera del hilo principal.
- **Mega menú:** 200 ms ease-out, ítems escalonados 40 ms.
- **Filas de servicios:** se abren y cambian la foto de vista previa con
  crossfade más blur, que tapa el salto entre dos imágenes distintas.
- **Reveal al entrar en pantalla:** visible por defecto, oculto sólo si el
  elemento está fuera de pantalla al cargar.

### La impronta de cada sección

El reveal **no es el mismo en toda la página**. Con un único gesto repetido, el
scroll se vuelve previsible y las secciones pierden carácter: se distinguen por
lo que dicen, no por cómo llegan.

Lo que se mantiene igual es el **encabezado**: todos los `h2` entran con
`riseIn`. Ese es el hilo que sostiene la página como un solo sistema. Lo que
cambia es el contenido, y cada gesto sale de la forma de lo que anima, no de
las ganas de variar:

| Sección | Gesto | Por qué |
|---|---|---|
| B2B | mosaicos que se posan (y + escala, escalonado en diagonal) | es una grilla de piezas, y se arman pieza por pieza |
| Clientes | sólo opacidad, de izquierda a derecha | pasar lista. Siete marcas heterogéneas moviéndose a la vez es ruido |
| B2C | los filetes se trazan de izquierda a derecha y el texto aparece | eje horizontal, el mismo de los filetes. La foto entra desde el lado opuesto |
| FAQ | las preguntas entran por los costados, una de cada lado | son cajas cerradas: una caja que se desliza se lee como una caja, no como una desalineación |
| Nosotras | la banda a sangre se descubre de arriba abajo con `clip-path` | la foto no se mueve, se revela; es el único gesto de recorte de la página |
| Recursos | cascada: cada tarjeta viene de más lejos y todas terminan a la vez | llegan en abanico y se emparejan |
| Contacto | un solo bloque, sin escalonar, el recorrido más largo | un formulario que aparece campo por campo se siente inestable |

Dos calibraciones que decidieron si esto se ve o no:

**Los rangos se miden sobre `cover`, no sobre `entry`.** El tramo `entry` de un
elemento dura lo que mide el elemento: para una fila de logos de 41 px, la
animación entera transcurre en 41 px de scroll y termina antes de que el
elemento esté bien a la vista. `cover` mide el paso completo por la ventana, así
que el gesto se ve mientras el elemento sube. Fue la razón principal por la que
la primera versión pasaba desapercibida.

**Cada gesto se apoya en una propiedad distinta**, no en una distancia distinta:
escala, opacidad, eje horizontal, eje vertical, recorte. Variar sólo cuántos
píxeles se desplaza un mismo movimiento no se percibe; cambiar qué propiedad se
mueve, sí. Es lo que permite que las amplitudes sean chicas y aun así se note
la diferencia: 30 px en horizontal se distinguen de 14 px en vertical porque el
eje cambia, no porque el recorrido sea grande.

**La opacidad termina al 55 % del recorrido, el desplazamiento sigue hasta el
final.** Lo que estorba la lectura no es que algo se mueva unos píxeles: es
tener que leer texto a medio opacar. Con este reparto el texto es legible
enseguida y lo único que queda por resolverse son los últimos píxeles del
movimiento, que el ojo ya no persigue.

**La FAQ además termina en el CTA.** Las seis preguntas están asentadas en el
instante en que el botón "Contactez une experte" asoma por abajo. Los topes no
se eligieron a ojo: en ese instante la última pregunta está al **8,6 %** de su
propio paso por la ventana, y ése es el techo de todo el conjunto.

Las seis arrancan en `cover 0%` y terminan escalonadas **hacia atrás** (11 %,
10,4 %… 8 %). Parece al revés y no lo es: cada pregunta está más abajo que la
anterior, así que entra en pantalla más tarde. Arrancar todas en 0 da igual una
entrada en secuencia, y los finales decrecientes hacen que las seis terminen
casi a la vez en scroll absoluto. Verificado a 1280×800, 1366×768, 1440×900 y
1512×982.

**Todo tiene que estar quieto antes de la zona de lectura.** Los rangos
terminan alrededor de `cover 20-30 %`, o sea cuando el elemento todavía está en
el tercio inferior de la pantalla. Si la animación sigue corriendo cuando el
contenido llegó al centro, la página se vuelve incómoda por más discreto que
sea el gesto. Se probó con rangos hasta `cover 40 %` y amplitudes del doble, y
era exactamente eso.

**Una caja sí puede entrar de costado; un renglón de texto no.** La FAQ entra
lateralmente y funciona, porque cada pregunta es una caja cerrada, con relleno
y borde, y una caja que se desliza se lee como una caja que se desliza. Las
filas de B2C no podían: eran renglones de texto alineados con el titular, y
cualquier desplazamiento lateral se leía como un error de maquetado. El gesto
no se elige por la sección, se elige por lo que hay dentro.

**Un gesto no puede romper una alineación, ni por un instante.** La primera
versión de B2C entraba la fila entera desplazada 30 px desde la izquierda. Como
las cuatro filas están alineadas entre sí y con el titular, mientras duraba el
escalonado se veían mal alineadas: la última todavía corrida cuando las de
arriba ya estaban en su sitio. No se lee como animación, se lee como un error
de maquetado. En una lista de renglones alineados lo que se mueve tiene que ser
otra cosa: acá se traza el filete con `scaleX` y el texto sólo aparece. Mismo
carácter horizontal, cero desplazamiento del texto.

**El escalonado no se hace con `animation-delay`.** Con `animation-timeline` el
delay se ignora: se corre el `animation-range` de cada elemento. Además de ser
lo único que funciona, ata el retardo al scroll y no al reloj, así que si
alguien sube y baja, la animación acompaña en vez de volver a arrancar.

Todo esto vive dentro de `@supports (animation-timeline: view())`. Un navegador
sin soporte recibe el `riseIn` parejo de siempre por `IntersectionObserver`, que
es una degradación correcta: pierde la impronta, no el contenido.

**`overflow: hidden` mata las animaciones de scroll de todo lo que tenga
adentro.** Un elemento con `overflow: hidden` es un contenedor de scroll, así
que el `view()` de sus descendientes se mide contra él y no contra la ventana;
como no scrollea, la línea de tiempo queda inactiva y la animación no corre
nunca. `.ct` lo tenía y el formulario de contacto aparecía sin ninguna entrada,
en silencio, sin error en consola. **Para recortar se usa `overflow: clip`**,
que recorta igual sin crear el contenedor. Es la misma razón por la que la raíz
usa `overflow-x: clip`. Si una sección deja de animar, esto es lo primero que
hay que mirar.

**Nunca** un listener de `scroll`. Sólo `IntersectionObserver` o
`animation-timeline`. Todo cae a estático bajo `prefers-reduced-motion`.

## Do's and Don'ts

### Do

- Un solo acento en toda la página, tomado de `:root`.
- Fotografía real del shooting. Hay 67 fotos y un video en `assets/`.
- Dos bandas de color pleno por página, siempre en la misma posición.
- Una familia de layout por sección.
- Marcar el contenido que falta con `.todo` en vez de inventarlo.
- Cifras reales o marcadas como pendientes. Nada de precisión falsa.

### Don't

- Un segundo acento porque una sección "pide color". Usá un tinte de fondo.
- Verde digital `#00ff5e` sobre blanco: da 1,4:1, es ilegible. Vive sólo sobre
  las bandas de color.
- Un label de versalitas sobre cada titular.
- Fondo de sección saturado. Sólo blanco y gris.
- Repetir el isotipo como viñeta, marca de agua o nodo. El logo va en header y
  footer, dos veces por página.
- Fondo de color detrás del texto de un ítem abierto: para eso está el acento
  en el título.
- Tres tarjetas iguales en fila.
- Sombras negras. Van tintadas con el acento.
- Nombres, logos, testimonios o cifras inventados. Es una consultora real con
  clientes reales.
- Radios sueltos fuera de la escala.

## Responsive

**Las pistas de grid traen `min-width: auto`**, así que un hijo que no encoge
(un `select`, un `input`, una palabra larga) desborda la columna y genera scroll
horizontal en pantallas chicas. Todos los contenedores de grid llevan
`min-width: 0` en sus hijos directos. Es la causa habitual del problema.

Por debajo de 1080 px el selector de idioma sale del header y pasa al pie del
menú desplegable: no entran logo, idioma, CTA y menú a la vez, y un selector que
sólo existe en escritorio deja al visitante de teléfono sin forma de cambiar de
idioma. El CTA se queda en todos los anchos, que es la acción principal del
sitio.

Ese selector del menú es el tercero de la página, junto con el del header y el
del pie. `build.py` reescribe **los tres**; si alguno quedara sin tocar, `/es/`
enlazaría a `/es/en/` y el idioma activo se marcaría en la página equivocada. El
script falla si no encuentra exactamente tres.

Breakpoints en 600, 900, 1080 y 1240 px. A 1080 el menú pasa a hamburguesa; a
1240 desaparece el rail lateral de secciones. Todo grid multicolumna colapsa a
una columna antes de 900.

El hero usa `svh`, nunca `vh`: en iOS la barra de direcciones hace saltar el
layout.

## Anclas y navegación

El rail lateral y los enlaces internos apuntan a `id` de sección. Dos reglas que
ya costaron un bug:

- **Un elemento `position: sticky` no sirve como destino de ancla.** El hero
  está pegado arriba, así que el navegador considera que ya está a la vista y no
  scrollea. `#top` vive en un `div` de altura cero al principio del `body`, no
  en el hero.
- Ese mismo `div` no cae nunca en la banda central del `rootMargin` del
  observer, así que el estado activo de `#top` lo maneja la sentinela del
  header, no el observer de secciones.

Las secciones llevan `scroll-margin-top: calc(var(--nav-h) + 12px)` para que la
barra fija no tape el titular al llegar.

## Iteration Guide

Para cambiar la paleta entera, tocá el bloque `:root` de
`assets/css/styles.css` y nada más. Hay una variante con la paleta primaria del
brand book (negro, violeta oscuro `#202045`, violeta claro `#a67bff`, verde
digital) que usa exactamente este mismo CSS con otros 29 valores.

Para agregar una página, seguí la escala de radios, el gap de 14 px y el
contenedor de 1360. Y antes de dar por terminada una sección, comprobá que su
familia de layout no se repite con ninguna de las que ya están.

## Fuente de contenido: `Textos_web.md`

El documento de la clienta (descarga del Google Doc) es la **única fuente de
texto**. Todo lo que está en él va literal a la página; todo lo que no está se
marca con `.todo` y no se inventa. Volcado del 23/09 en la home:

| Sección | Qué entró del doc |
| --- | --- |
| Entreprises | Cuerpo real; H1 = opción 1 de las dos del doc; CTA = opción 1 de cuatro |
| Particuliers | Cuerpo real + **los seis servicios** (antes eran cuatro inventados); CTA = opción 1 de dos |
| À propos | H1 real + **los seis engagements** numerados; CTA "L'histoire d'Inward" |

Lo que quedó marcado porque el propio doc no lo resuelve:

- Bento 4 (Naturalisation): el doc duda entre ese servicio y *housing*
  («DUDA: Esto o housing?» en la landing Entreprise).
- Engagement 02 anuncia respuesta en **-12 h** y la landing Fundadoras dice
  **24 h**. Un solo plazo.
- F&Q: respuesta 1 sigue en lorem ipsum, respuesta 2 sin redactar.
- Los "voir plus" de cada servicio de particulares apuntan a la landing
  Particuliers, que todavía no existe.
- Blog y Términos y Condiciones están vacíos en el doc.

### Por qué cambiaron los altos

Seis servicios y seis engagements donde había cuatro y tres suman ~250 px. La
regla «cada sección entra entera en pantalla» se mantuvo comprimiendo la fila y
la franja, no el aire entre secciones, que es lo que da el ritmo:

- `.row-btn` 1,15rem → 0,68rem de padding vertical.
- `.about-band` 24svh → 9,8svh (la franja cede el alto que piden los seis
  engagements).
- `.pillars` pasa de tres columnas con filete vertical a **3×2** con filetes por
  posición y numeración por `counter()`, no escrita a mano.
- El enunciado de À propos ya no es grilla de dos columnas: el doc no trae
  párrafo de presentación, así que «Nos engagements, votre garantie» es el
  rótulo de la lista en vez de un lead inventado.

Medido a 1280×800 (728 px útiles): entreprises 697, particuliers 721, about
713, f&q 636, contact 696. A 1366×768 (696 útiles) ninguna entra, tampoco antes
de este cambio: ese alto está por debajo del piso de ~730 px del diseño.

## Regla: ninguna animación sigue cuando ya se ve el CTA

Lo que se hizo en la F&Q ahora vale para toda la página. El límite de cada
sección es **el instante en que su CTA asoma por el borde inferior**: a partir
de ahí no puede quedar nada moviéndose ni a medio opacar.

Los topes no se eligen a ojo. Para cada elemento:

```
scroll del CTA   = topeDoc(CTA) − alto de ventana
progreso(elem)   = (scrollCTA − (topeDoc(elem) − vh)) / (alto(elem) + vh)
```

El porcentaje que sale de ahí es el techo de su `animation-range`. Depende del
alto de ventana, así que se toma el más exigente de los tres medidos
(1920×1080 da siempre el techo más bajo):

| Sección | Techo medido | Rango aplicado |
| --- | --- | --- |
| Entreprises, tuiles | 18,4 % | `cover 0%` → 11 / 13 / 15 / 16,5 / 18 % |
| Particuliers, filas 1→6 | 28,4 → 6,7 % | `cover 0%` → 26 / 22 / 18 / 14 / 9 / 4,5 % |
| À propos | 21,9 % | 4 → 20 % (ya cumplía) |
| Contact | 28,1 % | 2 → 22 % (ya cumplía) |
| F&Q | 7,3 % | 0 → 11 … 8 % (ya cumplía) |

El patrón es siempre el mismo: **todas arrancan en `cover 0%` y los finales
bajan**. Parece al revés y no lo es: cada elemento está más abajo que el
anterior, así que entra en pantalla más tarde; con finales decrecientes todos
terminan casi a la vez en scroll absoluto.

Dos elementos quedan fuera de la regla a propósito: el propio CTA (su aparición
*es* el límite) y el parallax de la foto de À propos, que no es un reveal y
dura toda la sección. Ressources tampoco entra: su botón está arriba del
bloque, no después de las tarjetas.

Verificado con `verify.mjs`: a 1280×800, 1440×900 y 1920×1080 se scrollea al
instante exacto del CTA de cada sección y se recorre el DOM comprobando que
ningún descendiente animado tenga `opacity < 1` o un `transform` distinto de la
identidad.

## À propos sin foto

Se quitó la franja a sangre de la sección. Con eso desaparecen `.about-band`,
la animación `unveil` y el parallax de esa foto (el keyframe `parallax` ya no
tiene quién lo use y también se borró). `team.webp` sigue en el proyecto: la
usa la galería de particulares.

Sin la franja, la sección es **enunciado → rótulo → seis engagements → CTA**, y
el gesto de entrada es un fundido simple: una lista numerada no admite un
movimiento que compita con la numeración. Se devolvió el aire que se le había
quitado a `#about` para hacerle sitio a la foto (padding, `row-gap` y el margen
del rótulo vuelven a sus valores holgados). Queda en 684 px a 1280×800, la
sección más baja de la página después de la F&Q.

## El lila vuelve a la paleta

`--tint-3:#d2d2ff`. La paleta de acento pasa a tener tres tintes en vez de dos:
verde agua, lila y amarillo.

- **Pie de página**: el acento pasa de verde agua a lila. Los dos pasan de
  sobra sobre el negro del pie (13,1:1 el lila, 15,2:1 el verde agua), y el
  lila tiene la ventaja de no competir con el verde de los CTA. Pinta el hover
  de los enlaces y la píldora del idioma activo.
- **Bento de empresas**: la tercera celda pasa de gris a lila, así los tres
  tintes quedan repartidos (2 verde agua, 3 lila, 4 amarillo) y siguen siendo
  tres cajas tintadas contra dos planas, sin que ninguna pese más.
- Texto sobre lila: 13,1:1 en negro de marca, 10,6:1 en violeta oscuro.

Las preguntas de la F&Q **no** se tocan: quedaron en verde agua y amarillo por
decisión de la clienta. Si quiere el lila ahí también, es cambiar una regla.
