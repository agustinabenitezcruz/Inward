# -*- coding: utf-8 -*-
"""Las páginas del sitio, en un solo lugar.

`dir` es la ruta de la página respecto de la raíz del sitio, sin barra final.
La home es "". De acá salen tanto la profundidad (cuántos ../ hay que poner
delante de los recursos) como las rutas del selector de idioma, así que build.py
y tools/sync_shell.py leen los dos esta lista y no pueden discrepar.
"""

PAGES = [
    {"dir": "",            "title": "Home"},
    {"dir": "entreprises", "title": "Landing Entreprises"},
    # Pendientes: particuliers, qui-sommes-nous, blog, mentions-legales
]


def src_of(d):
    """Archivo fuente en francés de una página."""
    return (d + "/index.html") if d else "index.html"


def depth_of(d):
    return len([s for s in d.split("/") if s])


def prefix_of(d):
    """Lo que hay que anteponer a una ruta relativa a la raíz."""
    return "../" * depth_of(d)
